#include <iostream>
#include <string>
#include <fstream>
#include "password_functions.h"

bool isValidPassword(const std::string& password){
    //TODO: COMPLETE FUNC
}

void setNewPassword(const std::string& fileString){
    //TODO: COMPLETE FUNC
}


bool authenticate(const std::string& passwordFileString){
    //TODO: COMPLETE FUNC
}

